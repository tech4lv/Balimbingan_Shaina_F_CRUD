﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using MySql.Data.MySqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LIB_FINAL
{
    public partial class Form2 : Form
    {
        Database db = new Database();

        public Form2()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string studentID = txtID.Text.Trim();

            if (string.IsNullOrEmpty(studentID))
            {
                MessageBox.Show("Please enter Student ID.", "Validation Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtID.Focus();
                return;
            }

            DataTable dt = db.ExecuteQuery(
                "SELECT * FROM students WHERE student_id=@studentID",
                new MySqlParameter[] { new MySqlParameter("@studentID", studentID) }
            );

            if (dt.Rows.Count > 0)
            {
                Form4 frm4 = new Form4(studentID); 
                frm4.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Student ID not found.", "Login Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtID.Clear();
                txtID.Focus();
            }
        }
        

        private void guna2ImageButton1_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.Show();
            this.Hide();
        }
    }
}
