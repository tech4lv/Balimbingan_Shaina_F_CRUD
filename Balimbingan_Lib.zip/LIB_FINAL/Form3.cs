﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using MySql.Data.MySqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LIB_FINAL
{
    public partial class Form3 : Form
    {
        Database db = new Database();
        public Form3()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();

            if (string.IsNullOrEmpty(username))
            {
                MessageBox.Show("Please enter username.", "Validation Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtUsername.Focus(); return;
            }
            if (string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Please enter password.", "Validation Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPassword.Focus(); return;
            }

            DataTable dt = db.ExecuteQuery(
                "SELECT * FROM users WHERE username=@username AND password=@password AND role='admin'",
                new MySqlParameter[] {
                new MySqlParameter("@username", username),
                new MySqlParameter("@password", password)
                }
            );

            if (dt.Rows.Count > 0)
            {
                Form5 frm5 = new Form5();
                frm5.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Invalid username or password.", "Login Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtPassword.Clear(); txtPassword.Focus();
            }
        }
        

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void guna2ImageButton1_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.Show();
            this.Hide();
        }
    }
}
