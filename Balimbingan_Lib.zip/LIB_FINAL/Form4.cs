﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using MySql.Data.MySqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Guna.UI2.Native.WinApi;
using static LIB_FINAL.Lib;

namespace LIB_FINAL
{
    public partial class Form4 : Form
    {
        Database db = new Database();
        private string studentID;
        public Form4()
        {
            InitializeComponent();
           
            LoadBooks();
        }

        public Form4(string studentID)
        {
            InitializeComponent(); 
            this.studentID = studentID;
            LoadBooks();
        }

        private void LoadBooks()
        {
            try
            {
                dgvBooks.DataSource = db.ExecuteQuery("SELECT * FROM books");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading books: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
      
        private void btnSearch_Click(object sender, EventArgs e)
        {
            string search = txtSearch.Text.Trim();
            if (string.IsNullOrEmpty(search)) 
            { 
                MessageBox.Show("Enter a book title.", "Validation Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning); 
                txtSearch.Focus(); 
                return; 
            }

            try
            {
                dgvBooks.DataSource = db.ExecuteQuery("SELECT * FROM books WHERE title LIKE @search", new MySqlParameter[] { new MySqlParameter("@search", "%" + search + "%") });
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error searching books: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnBorrow_Click(object sender, EventArgs e)
        {
            if (dgvBooks.CurrentRow == null) 
            { 
                MessageBox.Show("Select a book to borrow.", "Validation Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning); 
                return; 
            }

            try
            {
                int bookId = Convert.ToInt32(dgvBooks.CurrentRow.Cells["id"].Value);
                bool available = Convert.ToBoolean(dgvBooks.CurrentRow.Cells["available"].Value);
                if (!available) 
                { 
                    MessageBox.Show("This book is unavailable.", "Borrow Error", MessageBoxButtons.OK, MessageBoxIcon.Error); 
                    return; 
                }

                DataTable dt = db.ExecuteQuery("SELECT * FROM borrowed_book WHERE student_id=@studentID AND book_id=@bookID AND return_date IS NULL",
                    new MySqlParameter[] { new MySqlParameter("@studentID", studentID), new MySqlParameter("@bookID", bookId) });
                if (dt.Rows.Count > 0) 
                { 
                    MessageBox.Show("You already borrowed this book.", "Borrow Error", MessageBoxButtons.OK, MessageBoxIcon.Error); 
                    return; 
                }

                db.ExecuteNonQuery("INSERT INTO borrowed_book(student_id, book_id) VALUES(@studentID, @bookID)",
                    new MySqlParameter[] { new MySqlParameter("@studentID", studentID), new MySqlParameter("@bookID", bookId) });
                db.ExecuteNonQuery("UPDATE books SET available=FALSE WHERE id=@bookID", new MySqlParameter[] { new MySqlParameter("@bookID", bookId) });

                MessageBox.Show("Book borrowed successfully!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadBooks();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error borrowing book: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            if (dgvBooks.CurrentRow == null) 
            { 
                MessageBox.Show("Select a book to return.", "Validation Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning); 
                return; 
            }

            try
            {
                int bookId = Convert.ToInt32(dgvBooks.CurrentRow.Cells["id"].Value);
                db.ExecuteNonQuery("UPDATE borrowed_book SET return_date=NOW() WHERE student_id=@studentID AND book_id=@bookID AND return_date IS NULL",
                    new MySqlParameter[] { new MySqlParameter("@studentID", studentID), new MySqlParameter("@bookID", bookId) });
                db.ExecuteNonQuery("UPDATE books SET available=TRUE WHERE id=@bookID", new MySqlParameter[] { new MySqlParameter("@bookID", bookId) });

                MessageBox.Show("Book returned successfully!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadBooks();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error returning book: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void guna2ImageButton1_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.Show();
            this.Hide();
        }
    }
}
