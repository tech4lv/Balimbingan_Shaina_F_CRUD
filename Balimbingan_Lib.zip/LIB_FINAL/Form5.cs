﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using MySql.Data.MySqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Guna.UI2.Native.WinApi;
using static LIB_FINAL.Lib;

namespace LIB_FINAL
{
    public partial class Form5 : Form
    {
        Database db = new Database();
       
        public Form5()
        {
            InitializeComponent();
            LoadBooks();
        }

        private void LoadBooks() => dgvBooks.DataSource = db.ExecuteQuery("SELECT * FROM books");

        private void btnADD_Click(object sender, EventArgs e)
        {
            string title = txtTitle.Text.Trim();
            string author = txtAuthor.Text.Trim();
            string yearText = txtYear.Text.Trim();
            string isbn = txtISBN.Text.Trim();

            if (string.IsNullOrEmpty(title) || string.IsNullOrEmpty(author) || string.IsNullOrEmpty(yearText) || string.IsNullOrEmpty(isbn))
            { MessageBox.Show("All fields are required.", "Validation Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
            if (!int.TryParse(yearText, out int year) || year <= 0) { MessageBox.Show("Enter a valid year.", "Validation Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning); txtYear.Focus(); return; }

            DataTable dt = db.ExecuteQuery("SELECT * FROM books WHERE isbn=@isbn", new MySqlParameter[] { new MySqlParameter("@isbn", isbn) });
            if (dt.Rows.Count > 0) { MessageBox.Show("ISBN already exists.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error); txtISBN.Focus(); return; }

            db.ExecuteNonQuery("INSERT INTO books(title, author, year, isbn) VALUES(@title,@author,@year,@isbn)",
                new MySqlParameter[] { new MySqlParameter("@title", title), new MySqlParameter("@author", author), new MySqlParameter("@year", year), new MySqlParameter("@isbn", isbn) });
            MessageBox.Show("Book added successfully!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            LoadBooks(); ClearFields();
        }

        private void btnUPDATE_Click(object sender, EventArgs e)
        {
            if (dgvBooks.CurrentRow == null) { MessageBox.Show("Select a book to update.", "Validation Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }

            string title = txtTitle.Text.Trim();
            string author = txtAuthor.Text.Trim();
            string yearText = txtYear.Text.Trim();
            string isbn = txtISBN.Text.Trim();

            if (string.IsNullOrEmpty(title) || string.IsNullOrEmpty(author) || string.IsNullOrEmpty(yearText) || string.IsNullOrEmpty(isbn))
            { MessageBox.Show("All fields are required.", "Validation Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
            if (!int.TryParse(yearText, out int year) || year <= 0) { MessageBox.Show("Enter a valid year.", "Validation Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning); txtYear.Focus(); return; }

            int bookId = Convert.ToInt32(dgvBooks.CurrentRow.Cells["id"].Value);
            db.ExecuteNonQuery("UPDATE books SET title=@title, author=@author, year=@year, isbn=@isbn WHERE id=@id",
                new MySqlParameter[] { new MySqlParameter("@title", title), new MySqlParameter("@author", author),
                new MySqlParameter("@year", year), new MySqlParameter("@isbn", isbn), new MySqlParameter("@id", bookId) });
            MessageBox.Show("Book updated successfully!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            LoadBooks(); ClearFields();
        }

           

        private void btnREMOVE_Click(object sender, EventArgs e)
        {
            if (dgvBooks.CurrentRow == null) { MessageBox.Show("Select a book to remove.", "Validation Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }

            int bookId = Convert.ToInt32(dgvBooks.CurrentRow.Cells["id"].Value);
            db.ExecuteNonQuery("DELETE FROM books WHERE id=@id", new MySqlParameter[] { new MySqlParameter("@id", bookId) });
            MessageBox.Show("Book removed successfully!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            LoadBooks();
        }

        private void ClearFields()
        {
            txtTitle.Clear();
            txtAuthor.Clear();
            txtYear.Clear();
            txtISBN.Clear();
        }

        private void guna2ImageButton1_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.Show();
            this.Hide();
        }

        private void txtTitle_TextChanged(object sender, EventArgs e)
        {
    
        }
    }
}
