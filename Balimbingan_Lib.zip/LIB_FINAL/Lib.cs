﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LIB_FINAL
{
    internal class Lib
    {
        internal static void AddBook(Book newBook)
        {
            throw new NotImplementedException();
        }

        internal static void DeleteBook(int iD)
        {
            throw new NotImplementedException();
        }

        internal static IList<Book> GetBooks()
        {
            throw new NotImplementedException();
        }

        internal static void UpdateBook(Book selectedBook)
        {
            throw new NotImplementedException();
        }

        public class Book
        {
            public int ID { get; set; }
            public string Title { get; set; }
            public string Author { get; set; }
            public string Year { get; set; }
            public string ISBN { get; set; }
            public bool IsBorrowed { get; set; }
        }
    }
}
